package com.lalocal.lalocal.model;

/**
 * Created by lenovo on 2016/6/22.
 */
public class ProductValueBean {
    public String text;
    public int type;
    public String photo;
}
