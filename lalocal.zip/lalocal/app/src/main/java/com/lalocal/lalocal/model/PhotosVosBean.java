package com.lalocal.lalocal.model;

/**
 * Created by lenovo on 2016/6/23.
 */
public class PhotosVosBean {

    public  String description;
    public String fileName;
    public int id;
    public int sort;
    public String title;
    public int type;
}
