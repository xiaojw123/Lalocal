package com.lalocal.lalocal.model;



/**
 * Created by lenovo on 2016/6/17.
 */
public class SpecialBannerBean  {
    public int id;
    public String title;
    public int type;
    public String content;
    public String description;
    public String authorName;
    public String photo;
    public String videoScreenShot;
    public String videoUrl;
    public Object publishedAt;
    public int readNum;
    public int praiseNum;
    public SpecialShareVOBean shareVO;

}
