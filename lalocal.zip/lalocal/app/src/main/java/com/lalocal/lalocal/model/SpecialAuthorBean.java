package com.lalocal.lalocal.model;

/**
 * Created by lenovo on 2016/6/17.
 */
public class SpecialAuthorBean {
    public int authorId;
    public String authorName;
    public String authorAvatar;
    public String description;
    public Object qrCode;
    public Object publicTitle;
    public Object publicDescription;
}
