package com.lalocal.lalocal.model;

import java.util.List;

/**
 * Created by lenovo on 2016/6/22.
 */
public class ProductDetailsBean {
    public String title;
    public int type;

    public List<ProductContentBean> content;
}
