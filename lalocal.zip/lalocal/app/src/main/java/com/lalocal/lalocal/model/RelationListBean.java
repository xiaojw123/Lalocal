package com.lalocal.lalocal.model;

/**
 * Created by lenovo on 2016/6/27.
 */
public class RelationListBean {
    public String photo;
    public int praiseNum;
    public int readNum;
    public int targetId;
    public String targetName;
    public int id;
    public int styleType;
    public Object price;
    public Object status;

}
