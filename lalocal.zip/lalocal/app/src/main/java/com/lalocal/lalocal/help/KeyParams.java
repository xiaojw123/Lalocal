package com.lalocal.lalocal.help;

/**
 * Created by xiaojw on 2016/6/16.
 */
public interface KeyParams {
    public static  final String EMAIL="email";
    public static final  String PHONE="phone";
    public static final  String AREA_Code="areaCode";
    public static  final String NICKNAME="nickname";
    public static final String USERID="userid";
    public static final  String TOKEN="token";
    public static final  String STATUS="status";
    public static  final  String AVATAR="avatar";
    public static  final  String ORDER_ID="orderid";
    public static  final  String TRAVEL_PERSONS_CONCACT="concact";
    public static  final String SETTING="setting";
    public static  final  String IM_LOGIN="im_login";
    public static  final  String PASSWORD="psw";
    public static  final  String IS_LOGIN="isLogin";
}
