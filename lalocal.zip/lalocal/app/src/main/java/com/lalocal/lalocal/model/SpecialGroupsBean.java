package com.lalocal.lalocal.model;

import java.util.List;

/**
 * Created by lenovo on 2016/6/17.
 */
public class SpecialGroupsBean {
    public int id;
    public String title;
    public String description;
    public Object photo;
    public int targetType;
    public List<RelationListBean> relationList;
}
